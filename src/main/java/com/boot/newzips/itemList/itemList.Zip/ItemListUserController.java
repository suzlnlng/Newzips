	package com.boot.newzips.itemList;
	
	import java.util.ArrayList;

	import java.util.List;
	import java.util.Map;
	
	import javax.annotation.Resource;
	
	

	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

	import org.springframework.web.bind.annotation.RestController;
	import org.springframework.web.servlet.ModelAndView;
	

	import com.boot.newzips.dto.ListAllDTO;
	

	
	@RestController
	public class ItemListUserController {
	
	    @Resource
	    private itemListUserService itemListUserService;
	
	    @GetMapping("/newzips/itemList_user")
	    public ModelAndView itemListUser() {
	        ModelAndView mav = new ModelAndView();
	        mav.setViewName("user/ItemList_user"); 
	 
	       
	        return mav;
	    }

	    
	    
	    @PostMapping(value = "/newzips/itemList_user")
	    public List<ListAllDTO> getReadDataAll(@RequestBody Map<String, Object> requestData) {
	        int start = (int) requestData.get("start");
	        int end = (int) requestData.get("end");
	        // 적절한 데이터를 담은 ListAllDTO 객체 리스트 생성
	        List<ListAllDTO> result = new ArrayList<>();
	        for (int i = start; i <= end; i++) {
	            ListAllDTO dto = new ListAllDTO();
	            // dto 객체에 필요한 데이터 설정
	            result.add(dto);
	        }
	        return result;
	    }

	    
	    
	
	}
